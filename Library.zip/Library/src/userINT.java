public interface userINT {
public void creatuser(User us);
public void deleteuser(int ID);
public void showAllusesrnames(String name);


}
