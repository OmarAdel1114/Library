public class userDB implements requestInt {

    @Override
    public void buy() {
    // inserst into request =(?(name),?(requestID))
    }



    @Override
    public void cancelOreder(int ID) {
    // delete request which requestID = ?
    }
}
