public interface requestInt {
public void buy();
public void cancelOreder(int ID);

}
