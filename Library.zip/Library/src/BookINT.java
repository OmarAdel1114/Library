public interface BookINT {
public void creatbook();
public void deletbook(int ID);

}
